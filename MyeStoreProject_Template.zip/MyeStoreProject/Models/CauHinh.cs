﻿using System;
using System.Collections.Generic;

namespace MyeStoreProject.Models
{
    public partial class CauHinh
    {
        public int? SoSanPham1Trang { get; set; }
        public int? SoTrang { get; set; }
        public int? SoNgayHetHanQc { get; set; }
    }
}
